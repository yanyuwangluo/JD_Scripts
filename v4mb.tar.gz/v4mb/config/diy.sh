#!/usr/bin/env bash

#增加环境变量，按个人需要开启启动项,true开启，false关闭
export ENABLE_WEB_PANEL=true  #开启网页控制面板
export ENABLE_HANGUP=true     #开启财富岛热气球挂机

#定义目录
PanelBackupPath=$JD_DIR/config/panel
PanelPath=$JD_DIR/panel
Serverfile=$PanelPath/server.js
Authfile=$JD_DIR/config/auth.json

#清空pm2日志
rm -rf /root/.pm2/logs/* 2>/dev/null  

#判断panel文件夹是否存在，若不存在，复制/jd目录内
if [[ ! -d "$PanelPath" ]]; then
 echo "控制面板已和谐，重新拷贝面板目录..."
 cp -r /jd/config/v4mb/panel /jd/
 cp /jd/config/v4mb/20-jup /etc/cont-init.d/20-jup
 cp /jd/config/v4mb/jshare.sh /jd/jshare.sh
 echo "启动控制面板挂载程序..."
 pm2 stop /jd/panel/server.js
 pm2 start /jd/panel/server.js
else
 echo "控制面板还存在."
fi

#判断auth.json文件是否存在
if [ ! -f "$Authfile" ];then
echo "auth.json文件缺失，创建auth.json文件..."
touch $Authfile
echo '{"user":"admin","password":"adminadmin"}' > $Authfile
echo "auth.json文件创建成功！"
fi

#启动控制面板
echo -e "======================== 启动控制面板 ========================\n"
if [[ $ENABLE_WEB_PANEL == true ]]; then
    pm2 id server
    server_check_results=$(pm2 id server)
    if [[ $server_check_results == "[]" ]]; then
        pm2 start $Serverfile
        if [[ $? -eq 0 ]]; then
            echo -e "控制面板启动成功...\n"
            echo -e "如未修改用户名密码，则初始用户名为：admin，初始密码为：adminadmin\n"
            echo -e "请访问 http://<ip>:5678 登陆并修改配置...\n"
        else
            echo -e "控制面板启动失败或控制面板已经启动了，容器将继续启动...\n"
        fi
    else
    echo -e "控制面板已经启动了.\n"
    fi
elif [[ $ENABLE_WEB_PANEL == false ]]; then
    echo -e "已设置为不自动启动控制面板，跳过...\n"
fi

#启动挂机程序
if [[ $ENABLE_HANGUP == true ]]; then
    echo -e "======================== 启动挂机程序 ========================\n"
    pm2 id jd_cfd_loop
    hangup_check_results=$(pm2 id jd_cfd_loop)
    if [[ $hangup_check_results == "[]" ]]; then
        . $JD_DIR/config/config.sh
        if [[ $Cookie1 ]]; then
            jtask hangup 2>/dev/null
            echo -e "挂机程序启动成功...\n"
        else
            echo -e "config.sh中还未填入有效的Cookie，可能是首次部署容器，因此不启动挂机程序...\n"
        fi
    else
    echo -e "挂机程序已经启动了.\n"
    fi
elif [[ ${ENABLE_HANGUP} == false ]]; then
    echo -e "已设置为不自动启动挂机程序，跳过...\n"
fi